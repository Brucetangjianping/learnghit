package com.youzijie.mp.dao;

/**
 * Created by lei on 2015/7/22.
 */
public class WechatTemplateDo {
    private String wechatId;
    private String templates;

    public String getWechatId() {
        return wechatId;
    }

    public void setWechatId(String wechatId) {
        this.wechatId = wechatId;
    }

    public String getTemplates() {
        return templates;
    }

    public void setTemplates(String templates) {
        this.templates = templates;
    }
}
