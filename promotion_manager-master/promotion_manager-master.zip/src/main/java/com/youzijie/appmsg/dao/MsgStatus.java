package com.youzijie.appmsg.dao;

/**
 * Created by lei on 2015/9/24.
 */
public class MsgStatus {
    public static final int INIT = 0;
    public static final int SAVED = 1;
    public static final int PRE_PUBLISH = 2;
    public static final int PUBLISHING = 3;
    public static final int FULL_PUBLISHED = 4;
    public static final int PARTIAL_PUBLISHED = 5;
}
