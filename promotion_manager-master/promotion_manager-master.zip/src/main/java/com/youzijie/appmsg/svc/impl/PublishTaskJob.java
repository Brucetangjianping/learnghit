package com.youzijie.appmsg.svc.impl;

import org.springframework.stereotype.Service;

/**
 * Created by lei on 2015/9/24.
 */

@Service
public class PublishTaskJob {
    //publi
}
