package com.youzijie.appmsg.po;

import java.util.List;

/**
 * Created by lei on 2015/7/21.
 */
public class WechatMsgPublishPo {
    private List<WechatArticlePo> articles;

    public List<WechatArticlePo> getArticles() {
        return articles;
    }

    public void setArticles(List<WechatArticlePo> articles) {
        this.articles = articles;
    }
}
