package com.youzijie.ueditor.Po;

/**
 * Created by lei on 2015/7/20.
 */
public class ImagePo {
    private String url;

    public ImagePo() {
    }

    public ImagePo(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
