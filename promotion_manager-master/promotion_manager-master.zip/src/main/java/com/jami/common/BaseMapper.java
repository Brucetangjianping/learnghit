package com.jami.common;

public interface BaseMapper {

}
