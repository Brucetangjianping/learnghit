package com.jami.common.controller;

/**
 * Created by felixzhao on 14-2-24.
 */
public class JamiBasicController {



}
