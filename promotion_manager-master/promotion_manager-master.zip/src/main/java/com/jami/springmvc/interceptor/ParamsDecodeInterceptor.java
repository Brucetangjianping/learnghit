package com.jami.springmvc.interceptor;

/**
 * Created by felixzhao on 14-8-18.
 */
public class ParamsDecodeInterceptor {
}
